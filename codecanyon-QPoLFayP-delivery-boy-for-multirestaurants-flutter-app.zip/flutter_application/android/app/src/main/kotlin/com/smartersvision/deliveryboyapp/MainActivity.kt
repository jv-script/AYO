package com.smartersvision.deliveryboy.delivery_boy

import io.flutter.embedding.android.FlutterActivity;

class MainActivity: FlutterActivity() {}